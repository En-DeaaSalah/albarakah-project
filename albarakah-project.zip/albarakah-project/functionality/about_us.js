$('#navbarSupportedContent ul li').removeClass("active");
$('#navbarSupportedContent ul #about-us').addClass('active');

function icon_hover(element){


    console.log("hover");

    element.classList.add("animate__animated", "animate__pulse");


  
}

function icon_Unhover(element){
    console.log("Unhover");
    element.classList.remove("animate__animated", "animate__pulse");

}






function onVisible(element, callback) {
    new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if(entry.intersectionRatio > 0) {
          callback(element);

          if(element.id=="footer-row"||element.id=="banner-row")
          {
           
          }


          else if(element.id=="first_icons_row"){
            element.classList.add("animate__animated", "animate__backInLeft");
            observer.disconnect();
          }
        else{

            element.classList.add("animate__animated", "animate__backInRight");
            observer.disconnect();
        }

        
        
        }
      });
    }).observe(element);
  }
  onVisible(document.querySelector("#first_icons_row"), () => console.log("it's visible"));
  onVisible(document.querySelector("#secon_icons_row"), () => console.log("it's visible"));



  let go_top_btn = document.querySelector("#m");

  

  onVisible(document.querySelector("#footer-row"), () => {
	go_top_btn.style.visibility = "visible";
  });

  onVisible(document.querySelector("#banner-row"), () => {
	go_top_btn.style.visibility = "hidden";
  });

 

  function scroll_to_top() {
	window.scrollTo(0, 0);
  }



  onVisible(document.querySelector("#footer-row"), () => {
	go_top_btn.style.visibility = "visible";
  });

  onVisible(document.querySelector("#banner-row"), () => {
	go_top_btn.style.visibility = "hidden";
  });

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  $('html,body').animate({ scrollTop: 0 }, 'slow');
  // document.body.scrollTop = 0;
  // document.documentElement.scrollTop = 0;
  // window.scrollTo(0, 0);

}