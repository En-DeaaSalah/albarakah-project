$('#navbarSupportedContent ul li').removeClass("active");
$('#navbarSupportedContent ul #remot-service').addClass('active');