
document.querySelector("#logo-img").src="../images/logo.jpg";

document.querySelector("#logo-footer-img").src="../images/logo.jpg";

document.querySelector("#credit-cards-img").src="../images/visa.png";


document.querySelector("#contact-us-link").href="contact-us.php";

document.querySelector("#remot-service-link").href="remote_service.php";

document.querySelector("#Mechanism-work-link").href="Mechanism-work.php";

document.querySelector("#donation-link").href="donation.php";

document.querySelector("#about-us-link").href="about-us.php";

document.querySelector("#home-page-link").href="../index.php";

