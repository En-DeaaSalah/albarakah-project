$('#navbarSupportedContent ul li').removeClass("active");
$('#navbarSupportedContent ul #donation').addClass('active');