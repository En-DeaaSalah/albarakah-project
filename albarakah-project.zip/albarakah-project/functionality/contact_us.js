$('#navbarSupportedContent ul li').removeClass("active");
$('#navbarSupportedContent ul #contact-us').addClass('active');



function initMap(){

    


    map = new google.maps.Map(document.querySelector("#map"), {
        center: {lat: 33.537376465985744, lng: 36.29998381704983},
        zoom: 16
      });


}


(function () {
    'use strict'
  
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')
  
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
      .forEach(function (form) {
        form.addEventListener('submit', function (event) {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }
  
          form.classList.add('was-validated')
        }, false)
      })
  })()






  function checkFromValidity(){
    let f1=document.querySelector("#firstName");
    let f2=document.querySelector("#lastName");
    let f3=document.querySelector("#email");
    let f4=document.querySelector("#message");


 

   


    if(f1.value==""||f2.value==""||f3.value==""||f4.value==""){


        return false;


    }
    return true;
  





  }





  function sendForm(){
    let contactForm=document.querySelector("#contact-form");
    let iconWait=document.querySelector("#waitIcon");
    let submitButton=document.querySelector("#submitButton");

    submitButton.click();

    console.log(checkFromValidity());

    if(checkFromValidity()){

      
        iconWait.style.visibility="visible";
        contactForm.style.filter="blur(16px)";
       
        contactForm.reset();

    }
    
    
    
   

  }

 
function onVisible(element, callback) {
    new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if(entry.intersectionRatio > 0) {
          callback(element);

          if(element.id=="contacu-us-channels-row"){

            element.classList.add("animate__animated", "animate__lightSpeedInRight");

          }else{

            element.classList.add("animate__animated", "animate__slideInUp");
          }

          

        console.log("I can see you (-_-)");
          observer.disconnect();
        }
      });
    }).observe(element);
  }
  onVisible(document.querySelector("#contacu-us-channels-row"), () => console.log("it's visible"));
  onVisible(document.querySelector("#map-row"), () => console.log("it's visible"));

 
