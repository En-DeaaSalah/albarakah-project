$('#navbarSupportedContent ul li').removeClass("active");
$('#navbarSupportedContent ul #Mechanism-work').addClass('active');