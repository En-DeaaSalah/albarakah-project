
$('#navbarSupportedContent ul li').removeClass("active");
$('#navbarSupportedContent ul #home-page').addClass('active');

document.querySelector("#logo-img").src="images/logo.jpg";

document.querySelector("#logo-footer-img").src="images/logo.jpg";

document.querySelector("#credit-cards-img").src="images/visa.png";



document.querySelector("#contact-us-link").href="pages/contact-us.php";

document.querySelector("#remot-service-link").href="pages/remote_service.php";

document.querySelector("#Mechanism-work-link").href="pages/Mechanism-work.php";

document.querySelector("#donation-link").href="pages/donation.php";

document.querySelector("#about-us-link").href="pages/about-us.php";



















  let go_top_btn = document.querySelector("#m");

  function scroll_to_top() {
	window.scrollTo(0, 0);
  }

  function onVisible(element, callback) {
	new IntersectionObserver((entries, observer) => {
	  entries.forEach((entry) => {
		if (entry.intersectionRatio > 0) {
		  callback(element);
		  // observer.disconnect();

		 

		}
	  });
	}).observe(element);
  }

  onVisible(document.querySelector("#activities"), () => {
	go_top_btn.style.visibility = "visible";
  });

  onVisible(document.querySelector("#news_header"), () => {
	go_top_btn.style.visibility = "hidden";
  });

  var tooltipTriggerList = [].slice.call(
	document.querySelectorAll('[data-bs-toggle="tooltip"]')
  );
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
	return new bootstrap.Tooltip(tooltipTriggerEl);
  });


  let flag = false;
function myfunc() {

	let mediaQuery = window.matchMedia("(max-width:768px)");

	
	let x = document.querySelector("#mybutton");

	
	if (flag) {

		if(mediaQuery.matches)
		{
			x.style. transform = "translateX(0px)";

		}else{

			x.style. transform = "translateX(0px)";
		}

		
		flag = false;
	} else {


		if(mediaQuery.matches){

			x.style. transform = "translateX(205px)";

		}else{

			x.style. transform = "translateX(400px)";

		}
	 
	  flag = true;
	}
  }

  (function () {
	'use strict'
  
	// Fetch all the forms we want to apply custom Bootstrap validation styles to
	var forms = document.querySelectorAll('.needs-validation')
  
	// Loop over them and prevent submission
	Array.prototype.slice.call(forms)
	  .forEach(function (form) {
		form.addEventListener('submit', function (event) {
		  if (!form.checkValidity()) {
			event.preventDefault()
			event.stopPropagation()
		  }
  
		  form.classList.add('was-validated')
		}, false)
	  })
  })()





