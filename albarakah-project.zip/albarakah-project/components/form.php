<div class="continer" id="body-form">
    <form class="row needs-validation" novalidate action="https://formsubmit.co/23efbb6d20eb9936eccbfef450d595e2"
        method="POST">


        <input type="text" name="_honey" style="display:none">
        <input type="hidden" name="_captcha" value="false">


        <div class="col-12 form-group-col">
            <div class="form-group" id="form-background">

            </div>
        </div>


        <div class="col-12 form-group-col">
            <div class="form-group" id="form-info">
                <p>طلب تدريب مهني</p>
                <ul>

                    <li>المعلومات خاصة بالجمعية فقط</li>
                    <li>يحق للجمعية الاعتذار عن قبول الطلب دون إبداء الأسباب</li>
                    <li>تعتبر أي معلومة ناقصة أو غير صحيحة سبباً كافياً لإلغاء الطلب</li>

                </ul>
            </div>
        </div>



        <div class="col-12 form-group-col">
            <div class="form-group">
                <label for="InputName"> الاسم الثلاثي :</label>
                <input type="text" class="form-control" id="InputName" aria-describedby="nameHelp"
                    placeholder="ادخل اسمك" required name="name" />
                <small id="nameHelp" class="form-text text-muted">يعتبر الطلب لاغياً حال عدم المطابقة مع معلومات الهوية
                    الشخصية
                    باللغة العربية</small>


                <div class="valid-feedback">
                    تم
                </div>
                <div class="invalid-feedback">
                    من فضلك ادخل معلومات الحقل
                </div>
            </div>
        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <p>الجنسية:</p>
                <select class="form-select" required>
                    <option value="1">سورية</option>
                    <option value="2">فلسطينية سورية</option>
                </select>
            </div>
            <div class="valid-feedback">
                تم
            </div>
            <div class="invalid-feedback">
                من فضلك ادخل معلومات الحقل
            </div>
        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <p>الجنس :</p>

                <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="customControlValidation2" name="radio-stacked"
                        required name="sex" />
                    <label class="custom-control-label" for="customControlValidation2">ذكر</label>
                </div>
                <div class="custom-control custom-radio mb-3">
                    <input type="radio" class="custom-control-input" id="customControlValidation3" name="radio-stacked"
                        required />
                    <label class="custom-control-label" for="customControlValidation3">انثى</label>
                </div>
            </div>
            <div class="valid-feedback">
                تم
            </div>
            <div class="invalid-feedback">
                من فضلك ادخل معلومات الحقل
            </div>
        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <label for="IdNumber">الرقم الوطني :</label>
                <input type="number" class="form-control" id="IdNumber" aria-describedby="IdNumberHelp"
                    placeholder="ادخل رقمك الوطني" required />
                <small id="IdNumberHelp" class="form-text text-muted">يعتبر الطلب لاغياً إن لم تكن الإجابة دقيقة فهو
                    لضمان عدم تكرار
                    الاسماء في طلبات الجمعية</small>
                <div class="valid-feedback">
                    تم
                </div>
                <div class="invalid-feedback">
                    من فضلك ادخل معلومات الحقل
                </div>
            </div>
        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <label for="exampleInputEmail1"> رقم الهاتف :</label>
                <input type="number" class="form-control" id="exampleInputEmail1" placeholder="ادخل رقم هاتفك الثابت"
                    required name="phone" />
                <div class="valid-feedback">
                    تم
                </div>
                <div class="invalid-feedback">
                    من فضلك ادخل معلومات الحقل
                </div>
            </div>
        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <label for="phoneNumber">رقم الجوال :</label>
                <input type="number" class="form-control" id="phoneNumber" placeholder="ادخل رقم هاتفك المحمول" required
                    name="phone" />
                <div class="valid-feedback">
                    تم
                </div>
                <div class="invalid-feedback">
                    من فضلك ادخل معلومات الحقل
                </div>
            </div>
        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <label for="InputEmail1">البريد الإلكتروني :</label>
                <input type="email" class="form-control" id="InputEmail1" placeholder="ادخل بريدك الإلكتروني" required
                    name="email" />
                <div class="valid-feedback">
                    تم
                </div>
                <div class="invalid-feedback">
                    من فضلك ادخل معلومات الحقل
                </div>
            </div>
        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <label for="address">عنوان السكن الحالي :</label>
                <input type="text" class="form-control" id="address" placeholder="ادخل عنوان سكنك" required
                    name="location" />
                <div class="valid-feedback">
                    تم
                </div>
                <div class="invalid-feedback">
                    من فضلك ادخل معلومات الحقل
                </div>


            </div>

        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <label for="studyInput">أدرس حالياً :</label>
                <input type="text" class="form-control" id="studyInput" placeholder="ادخل نوع دراستك" required
                    name="study" />
            </div>
        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <label for="specialization">الاختصاص :</label>
                <input type="text" class="form-control" id="specialization" placeholder="ادخل تخصصك" required />
                <div class="valid-feedback">
                    تم
                </div>
                <div class="invalid-feedback">
                    من فضلك ادخل معلومات الحقل
                </div>


            </div>

        </div>

        <div class="col-12 form-group-col">
            <div class="form-group">
                <label for="courses">الدورات السابقة ومكانها :</label>
                <input type="text" class="form-control" id="courses" required />
                <div class="valid-feedback">
                    تم
                </div>
                <div class="invalid-feedback">
                    من فضلك ادخل معلومات الحقل
                </div>

            </div>

        </div>



        <div class="col-12" id="submitForm">
            <button class="btn btn-primary" type="submit">ارسال الطلب</button>

            <!-- <input type="submit" class="btn btn-primary" value="ارسال الطلب"> -->
        </div>




    </form>
</div>