<footer class="bg-light text-center text-white">
    <div class="container-fluid" id="x">
        <div class="row"></div>

        <div class="row justify-content-end" id="y">
            <div class="col-lg-4 col-sm-12" id="logo-footer">
                <img id="logo-footer-img" src="" alt="" />
            </div>

            <div class="col-lg-4 col-sm-12" id="Supported-credit-cards">
                <p>هنا تقبل بطاقات الدفع</p>

                <img id="credit-cards-img" src="" alt="credit-cards" />
            </div>

            <div class="col-lg-4 col-sm-12" id="Social-media">
                <!-- Facebook -->

                <div id="Social-media-title">
                    تابعونا على شبكات التواصل الإجتماعي
                </div>

                <div id="Social-media-icons">
                    <a class="btn btn-primary btn-floating rounded-circle m-1" style="background-color: #3b5998"
                        href="#!" role="button"><i class="fab fa-facebook-f"></i></a>

                    <!-- Twitter -->
                    <a class="btn btn-primary btn-floating rounded-circle m-1" style="background-color: #55acee"
                        href="#!" role="button"><i class="fab fa-twitter"></i></a>

                    <!-- Google -->
                    <a class="btn btn-primary btn-floating rounded-circle m-1" style="background-color: #dd4b39"
                        href="#!" role="button"><i class="fab fa-google"></i></a>

                    <!-- Instagram -->
                    <a class="btn btn-primary btn-floating rounded-circle m-1" style="background-color: #ac2bac"
                        href="#!" role="button"><i class="fab fa-instagram"></i></a>

                    <!-- whatsapp -->
                    <a class="btn btn-primary btn-floating rounded-circle m-1" style="background-color: green" href="#!"
                        role="button"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
        <hr style="color: black" />

        <div class="row">
            <div id="Copyright" class="col-12 text-center p-3">
                جميع حقوق التأليف و النشر محفوظة.
                <a href="#"> جمعية البركة للتنمية الإجتماعية 2021</a>
            </div>
        </div>
    </div>
</footer>