<div class="row" id="nav-row">
    <div id="status-div" class="col-lg-2 col-sm-0">
        <div id="status">
            <i class="fas fa-clock fa-1x"></i>
            <span id="status-label"></span>
        </div>
        <div id="date">
            <i class="tooltip-inner fas fa-sort-down" data-bs-toggle="tooltip" title="8:00 AM - 4:00 PM :  السبت
    
                     8:00 AM - 4:00 PM :   الاحد    
            
                     8:00 AM - 4:00 PM : الاثنين
            
                     8:00 AM - 4:00 PM :الثلاثاء
            
                     8:00 AM - 4:00 PM :الاربعاء
                  
                     8:00 AM - 4:00 PM : الخميس
                   
                      الجمعة : مغلق"><span>8:00 AM - 4:00 PM</span></i>
        </div>
    </div>

    <div class="col-lg-7 col-sm-3">
        <nav class="navbar navbar-expand-custom navbar-mainbg">
            <button class="navbar-toggler" type="button" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fas fa-bars text-white"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <div class="hori-selector">
                        <div class="left"></div>
                        <div class="right"></div>
                    </div>

                    <li class="nav-item" id="contact-us">
                        <a class="nav-link" href="#" id="contact-us-link">
                            <i id="contact-us-icon" class="fas fa-headset"></i>

                            اتصل بنا</a>
                    </li>
                    <li class="nav-item" id="remot-service">
                        <a class="nav-link" href="#" id="remot-service-link"><i id="remot-service-icon"
                                class="far fa-address-book"></i>الخدمات
                            الالكترونية</a>
                    </li>
                    <li class="nav-item" id="Mechanism-work">
                        <a class="nav-link" href="#" id="Mechanism-work-link">
                            <i id="Mechanism-work-icon" class="fas fa-cogs"></i>

                            ألية العمل</a>
                    </li>
                    <li class="nav-item" id="donation">
                        <a class="nav-link" href="#" id="donation-link"><i id="donation-icon"
                                class="fas fa-hand-holding-usd"></i>تبرع</a>
                    </li>

                    <li class="nav-item" id="about-us">
                        <a class="nav-link" href="#" id="about-us-link"><i id="about-us-icon"
                                class="fas fa-address-card"></i>من نحن</a>
                    </li>

                    <li class="nav-item active" id="home-page">
                        <a class="nav-link" href="#" id="home-page-link">
                            <i id="home-page-icon" class="fas fa-home"></i>الرئيسية</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>

    <span id="company-row" class="col-lg-3 row">
        <div id="navbar-logo-div" class="col-4">
            <img id="logo-img" src="" alt="logo" />
        </div>

        <div id="navbar-title-div" class="col-8">
            <a class="navbar-brand navbar-title" href="#" onmouseover="logo_animation()">جمعية البركة للتنمية الإجتماعية
            </a>
        </div>


    </span>

</div>