<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    <meta name="viewport" content="width=device-width,user-scalable=0">





    <link rel="stylesheet" href="../styles/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../styles/fontawesome-free-5.15.4-web/css/all.css" />
    <link rel="stylesheet" href="../styles/header-style.css">
    <link rel="stylesheet" href="../styles/footer-style.css">
    <link rel="stylesheet" href="../styles/contact-us.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />


    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBO5ananCjssDObklAg8Q4vNfy9VNPgBzM&callback=initMap">
    </script>
    <title>contact-us</title>

</head>

<body>


    <div class="continer-fluid">

        <div class="row" id="header-row">

            <div class="col">

                <?php require "../components/header.php"; ?>


            </div>
        </div>

        <div class="row" id="background-row">


            <div class="col-lg-12">


                <img id="background-img" src="../images/contact-us.jpg" alt="background" width="100%">

            </div>



        </div>




        <div class="row" id="form-row">


            <div class="continer">



                <div class="col-12 text-center" id="waitIcon">
                    <i class="fas fa-spinner fa-pulse fa-10x"></i>
                </div>






                <form class="row m-3 needs-validation" novalidate dir="rtl"
                    action="https://formsubmit.co/23efbb6d20eb9936eccbfef450d595e2" method="POST" id="contact-form">


                    <div id="form-title-continer" class="clo-lg-12 text-center">



                        <h3 id="form-title">
                            نموذج الإستفسارات والإقتراحات


                        </h3>

                        <p class="lead">
                            جاهزون للرد على استفساراتكم
                        </p>


                    </div>

                    <input type="text" name="_honey" style="display:none">
                    <input type="hidden" name="_captcha" value="false">
                    <!-- <input type="hidden" name="_next" value="http://localhost/t1/pages/text.php"> -->

                    <div class="col-lg-6 margin-bottom" id="name-input">
                        <label for="firstName" class="form-label">الاسم الاول:</label>
                        <input type="text" name="name" class="form-control" id="firstName" placeholder="ادخل اسمك"
                            required>
                        <div class="valid-feedback">
                            تم
                        </div>
                        <div class="invalid-feedback">
                            من فضلك ادخل معلومات الحقل
                        </div>
                    </div>
                    <div class="col-lg-6 margin-bottom" id="family-input">
                        <label for="lastName" class="form-label">العائلة:</label>
                        <input type="text" name="family" class="form-control" id="lastName"
                            placeholder="ادخل اسم عائلتك" required>
                        <div class="valid-feedback">
                            تم
                        </div>
                        <div class="invalid-feedback">
                            من فضلك ادخل معلومات الحقل
                        </div>
                    </div>
                    <div class="col-lg-8 margin-bottom" id="email-input">
                        <label for="email" class="form-label">البريد الالكتروني:</label>
                        <input type="email" name="email" class="form-control" id="email"
                            placeholder="ادخل بريدك الالكتروني" required>
                        <div class="valid-feedback">
                            تم
                        </div>
                        <div class="invalid-feedback">
                            من فضلك ادخل معلومات الحقل
                        </div>
                    </div>
                    <div class="col-lg-4 margin-bottom" id="phone-input">
                        <label for="phoneNumber" class="form-label">رقم الموبايل : (اختياري)</label>
                        <input type="text" name="phone" class="form-control" id="phoneNumber"
                            placeholder="ادخل رقم هاتفك المحمول">

                    </div>
                    <div class="col-lg-12 margin-bottom" id="message-input">
                        <label for="message" class="form-label">اقتراحات او استفسارات: </label>
                        <textarea name="message" id="message" class="form-control" required></textarea>
                        <div class="valid-feedback">
                            تم
                        </div>
                        <div class="invalid-feedback">
                            من فضلك ادخل معلومات الحقل
                        </div>
                    </div>
                    <div class="col-lg-12 my-5 text-center" id="button">
                        <button id="form-button" class="btn btn-primary" onclick="sendForm()">ارسال</button>

                        <input type="submit" id="submitButton" style="visibility: hidden;">



                    </div>


                    <input type="hidden" name="_template" value="box">


                </form>






            </div>






        </div>



        <div class="row" id="contacu-us-channels-row">



            <h2 class=" col-12 text-center" id="contact-us-label">
                ... اتصل بنا
            </h2>







            <div class="contact-channel col-sm-12 col-lg-2">+ 963 11 5118241 :هــاتــف <i class="fas fa-phone"></i>
            </div>
            <div class="contact-channel col-sm-12 col-lg-2">+ 963 991 086 666 :جوال<i class="fas fa-mobile"></i>
            </div>
            <div class="contact-channel col-sm-12 col-lg-2">+ 963 11 5118214 :تلفاكس<i class="fas fa-fax"></i>
            </div>
            <div class="contact-channel col-sm-12 col-lg-3"><a href="mailto:info@albarakah.net">info@albarakah.net</a>
                :البريد
                الإلكتروني
                <i class="fas fa-envelope-open-text"></i>
            </div>













        </div>


        <div class="row" id="map-row">





            <div class="col-lg-12">

                <h1 id="map-title" class="lead"><i class="fas fa-map-marker-alt"></i> موقعنا على الخريطة</h1>


            </div>


            <div class="col-lg-12">


                <!-- <div id="map"></div> -->

                <div id="map" class="mapouter">
                    <div class="gmap_canvas"><iframe width="656" height="500" id="gmap_canvas"
                            src="https://maps.google.com/maps?q=%D8%AC%D9%85%D8%B9%D9%8A%D8%A9%20%D8%A7%D9%84%D8%A8%D8%B1%D9%83%D8%A9%20%D8%B1%D9%83%D9%86%20%D8%A7%D9%84%D8%AF%D9%8A%D9%86&t=&z=15&ie=UTF8&iwloc=&output=embed"
                            frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a
                            href="https://putlocker-is.org"></a><br>
                        <style>
                        .mapouter {
                            position: relative;
                            text-align: right;
                            height: 500px;
                            width: 656px;
                        }
                        </style><a href="https://www.embedgooglemap.net">how do i add a google map to my website</a>
                        <style>
                        .gmap_canvas {
                            overflow: hidden;
                            background: none !important;
                            height: 500px;
                            width: 656px;
                        }
                        </style>
                    </div>
                </div>
            </div>


        </div>




        <div class="row">

            <div class="col">

                <?php require "../components/footer.php"; ?>
            </div>

        </div>
    </div>




    <script src="../functionality/jquery.js"></script>
    <script src="../styles/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../functionality/nav-controller.js"></script>
    <script src="../functionality/links.js"></script>
    <script src="../functionality/contact_us.js"></script>







</body>

</html>