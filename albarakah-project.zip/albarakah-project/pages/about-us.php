<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    <meta name="viewport" content="width=device-width,user-scalable=0">

    <link rel="stylesheet" href="../styles/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../styles/fontawesome-free-5.15.4-web/css/all.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="../styles/header-style.css">
    <link rel="stylesheet" href="../styles/footer-style.css">
    <link rel="stylesheet" href="../styles/baout-us.css">

    <title>about-us</title>

</head>

<body>


    <div class="continer-fluid h-100 d-flex flex-column">

        <div class="row" id="header-row">

            <div class="col-12">

                <?php require "../components/header.php"; ?>


            </div>
        </div>



        <div class="row" id="banner-row">



            <div class="col-lg-6 col-sm-12" id="logo-div">

                <img class="animate__animated animate__flip animate__delay-1s" src="../images/logo.jpg" alt="logo">


            </div>



            <div class="col-lg-6 col-sm-12 animate__animated animate__lightSpeedInRight" id="text-div">

                <i class="fas fa-map-pin fa-3x"></i>

                <h1>
                    النشأة والتأسيس

                </h1>

                <p>
                    تأسست جمعية البركة للتنمية الاجتماعية رسميا برقم 1588 بتاريخ 16-9-2010 م، والتي تهدف للتأهيل العلمي
                    والمهني للمحتاجين ليتمكنوا من العمل و الاكتفاء مادياً ,ومساعدتهم مادياً ومعنوياً، وذلك اقتداء بعمل
                    رسول الله صلى الله عليه وسلم مع السائل حيث اشترى له فأساً وأمره بالاحتطاب فعاد وقد كفاه الله تعالى
                    وأغناه عن السؤال.


                </p>






            </div>










        </div>






        <div id="first_icons_row" class="row h-30">

            <div class="col-lg-4 order-3 icon-div">


                <a><img onmouseover="icon_hover(this)" onmouseout="icon_Unhover(this)" class="icon"
                        src="../images/Briefcase.png" alt="" /></a>
                <div class="icon-text">
                    <h5 class="icon-title">مجلس الادارة</h5>
                    <p class="icon-p">
                        اعضاء مجلس الادارة
                    </p>
                </div>

            </div>





            <div class="col-lg-4 order-2 icon-div">


                <a> <img onmouseover="icon_hover(this)" onmouseout="icon_Unhover(this)" class="icon"
                        src="../images/Pencil-1.png" alt="" /></a>
                <div class="icon-text">
                    <h5 class="icon-title">الرؤية والرسالة</h5>
                    <p class="icon-p">
                        رؤية الجمعية ورسالتها </p>

                </div>





            </div>
            <div class="col-lg-4 order-1 icon-div">


                <a><img onmouseover="icon_hover(this)" onmouseout="icon_Unhover(this)" class="icon"
                        src="../images/Toggles.png" alt="" /></a>
                <div class="icon-text">
                    <h5 class="icon-title">الاهداف والقيم</h5>
                    <p class="icon-p">
                        اهداف الجمعية وقيمها الاستراتيجية ونطاق التطبيق
                    </p>

                </div>





            </div>


        </div>



        <div id="secon_icons_row" class="row h-30 ">

            <div class="col-lg-4 order-3 icon-div">


                <a><img onmouseover="icon_hover(this)" onmouseout="icon_Unhover(this)" class="icon"
                        src="../images/Chats.png" alt="" /></a>
                <div class="icon-text">
                    <h5 class="icon-title">لماذا جمعية البركة الخيرية</h5>
                    <p class="icon-p">
                        لماذا جمعية البركة الخيرية
                    </p>
                </div>

            </div>






            <div class="col-lg-4 order-2 icon-div">


                <a><img onmouseover="icon_hover(this)" onmouseout="icon_Unhover(this)" class="icon"
                        src="../images/Folder.png" alt="" /></a>
                <div class="icon-text">
                    <h5 class="icon-title">سياسة الجودة</h5>
                    <p class="icon-p">
                        سياسة ونطاق تطبيق نظام الجودة
                    </p>

                </div>





            </div>
            <div class="col-lg-4 order-1 icon-div">


                <a><img onmouseover="icon_hover(this)" onmouseout="icon_Unhover(this)" class="icon"
                        src="../images/Trophy.png" alt="" /></a>
                <div class="icon-text">
                    <h5 class="icon-title">شهادات الجودة</h5>
                    <p class="icon-p">
                        الشهادات التي حصلت عليها الجمعية </p>

                </div>





            </div>


        </div>


        <div class="row" id="footer-row">

            <div class="col-12">

                <?php require "../components/footer.php"; ?>
            </div>

        </div>



    </div>

    <button onClick="topFunction()" id="m" type="button" class="btn btn-warning btn-lg">
        <i class="fas fa-arrow-alt-circle-up fa-1x"></i>
    </button>




    <script src="../functionality/jquery.js"></script>
    <script src="../styles/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../functionality/nav-controller.js"></script>
    <script src="../functionality/links.js"></script>
    <script src="../functionality/about_us.js"></script>






</body>

</html>