<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../styles/fontawesome-free-5.15.4-web/css/all.css" />
    <link rel="stylesheet" href="../styles/header-style.css">
    <link rel="stylesheet" href="../styles/footer-style.css">
    <title>Mechanism-work</title>

</head>

<body>


    <div class="continer-fluid">

        <div class="row">

            <div class="col">
                <?php require "../components/header.php"; ?>


            </div>
        </div>
        <div class="row">

            <div class="col">

                <?php require "../components/footer.php"; ?>
            </div>

        </div>
    </div>




    <script src="../functionality/jquery.js"></script>
    <script src="../styles/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../functionality/nav-controller.js"></script>
    <script src="../functionality/links.js"></script>
    <script src="../functionality/Mechanism_work.js"></script>







</body>

</html>