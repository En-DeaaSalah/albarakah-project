<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0" /> -->
    <meta name="viewport" content="width=device-width,user-scalable=0">
    <link rel="stylesheet" href="styles/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="styles/fontawesome-free-5.15.4-web/css/all.css" />
    <link rel="stylesheet" href="styles/style.css" />
    <link rel="stylesheet" href="styles/header-style.css">
    <link rel="stylesheet" href="styles/footer-style.css">
    <link rel="stylesheet" href="styles/form-style.css">
    <title>جمعية البركة للتنمية الإجتماعية</title>
</head>

<body>
    <div class="container-fluid">



        <div class="row">


            <div class="col-12">

                <?php require "components/header.php"; ?>
            </div>






        </div>







        <div class="row" id="carousel-row">
            <div class="col-12" id="carousel-col">
                <div id="parent" class="carousel carousel-dark slide" data-bs-ride="carousel">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#parent" data-bs-slide-to="0" class="active"
                            aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#parent" data-bs-slide-to="1"
                            aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#parent" data-bs-slide-to="2"
                            aria-label="Slide 3"></button>
                    </div>

                    <div class="carousel-inner" id="carousel-inner1">
                        <div class="carousel-item active" data-bs-interval="2000">
                            <div class="content-1"></div>



                        </div>
                        <div class="carousel-item" data-bs-interval="2000">
                            <div class="content-2"></div>

                        </div>
                        <div class="carousel-item" data-bs-interval="2000">
                            <div class="content"></div>

                        </div>

                        <button id="mybutton" class="btn btn-primary" type="button" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling" onclick="myfunc()">
                            <div id="right_div" class="custom_div">
                                <i class="fas fa-arrow-right"></i>
                            </div>

                            <div id="left_div" class="custom_div">التبرع السريع</div>
                        </button>

                        <div class="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false"
                            tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
                            <div class="offcanvas-header">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                            data-bs-target="#home" type="button" role="tab" aria-controls="home"
                                            aria-selected="true">
                                            المشاريع
                                        </button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                                            data-bs-target="#profile" type="button" role="tab" aria-controls="profile"
                                            aria-selected="false">
                                            المساعدات العاجلة
                                        </button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab"
                                            data-bs-target="#contact" type="button" role="tab" aria-controls="contact"
                                            aria-selected="false">
                                            آخر الحملات
                                        </button>
                                    </li>
                                </ul>
                            </div>
                            <div class="offcanvas-body">
                                <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                                    <option selected>إختر مشروع</option>
                                    <option value="1">التسويق</option>
                                    <option value="2">التصميم الإعلاني</option>
                                    <option value="3">
                                        الوظائف الإدارية (سكرتارية , استقبال, موظفوا المقاسم,
                                        ......الخ)
                                    </option>
                                    <option value="4">المحاسبة و المستودعات</option>
                                    <option value="5">
                                        رعاية المسنين و المعالجة الفيزيائية
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <button class="carousel-control-prev" type="button" data-bs-target="#parent" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#parent" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>























        <div class="row" id="carousel-second-row">

            <div class="col-12" id="news-col">
                <div id="news-slider" class="carousel carousel-dark slide" data-interval="false">
                    <div class="carousel-indicators dotted-indicators">
                        <button type="button" data-bs-target="#news-slider" data-bs-slide-to="0" class="active"
                            aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#news-slider" data-bs-slide-to="1"
                            aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#news-slider" data-bs-slide-to="2"
                            aria-label="Slide 3"></button>
                    </div>

                    <div class="container-fluid carousel-inner" id="carousel-inner2">

                        <div class="col-12" id="news_header">
                            <h3>آخر الأخبار</h3>

                            <p class="lead">
                                تابع آخر أخبار الجمعية وأخبار النشاطات التدريبية الخيرية ،الأخبار
                                العامة ، وأخبار اللجان المخصصة داخل جمعية البركة للتنمية الإجتماعية
                            </p>
                        </div>

                        <div class="row carousel-item active post-continer">
                            <div class="col-sm-12 col-lg-5 post container-fluid" id="post-1">

                                <div class="row">

                                    <div class="post-img col-lg-5 col-sm-12">
                                        <img src="images/post-1.jpg" alt="news-img">
                                    </div>
                                    <div class="post-content col-lg-7 col-sm-12">

                                        <h5>
                                            هنا سيكون عنوان الخبر
                                        </h5>

                                        <p>
                                            لتطبيق العملي في دورة المحاسبة العملية المتقدمة، يرفع سوية المتدربين
                                            وجاهزيتهم للدخول إلى سوق العمل..
                                            نرجو التوفيق والنجاح لجميع المتدربات..
                                        </p>
                                        <button class="btn btn-primary"><i class="fas fa-angle-double-left"></i>اقرا
                                            المزيد</button>
                                    </div>

                                </div>






                            </div>










                            <div class="col-sm-12 col-lg-5 post post-continer " id="post-2">

                                <div class="row">

                                    <div class="post-img col-lg-5 col-sm-12">
                                        <img src="images/web-design.jpg" alt="news-img">
                                    </div>
                                    <div class="post-content col-lg-7 col-sm-12">

                                        <h5>
                                            هنا سيكون عنوان الخبر
                                        </h5>

                                        <p>
                                            انطلاق المستوى الثالث من برنامج إدارة الشبكات..
                                            نرجو التوفيق والنجاح لجميع المتدربين..
                                        </p>
                                        <button class="btn btn-primary"><i class="fas fa-angle-double-left"></i>اقرا
                                            المزيد</button>
                                    </div>

                                </div>


                            </div>









                        </div>








                        <div class="row carousel-item post-continer">
                            <div class="col-sm-12 col-lg-5 post container" id="post-3">

                                <div class="row">

                                    <div class="post-img col-lg-5 col-sm-12">
                                        <img src="images/post-2.jpg" alt="news-img">
                                    </div>
                                    <div class="post-content col-lg-7 col-sm-12">

                                        <h5>
                                            هنا سيكون عنوان الخبر
                                        </h5>

                                        <p>
                                            من مميزات المدرس الناجح عن غيره من المدرسين، تمكنه من حل المشكلات بأبسط
                                            الحلول الممكنة..
                                            نرجو التوفيق والنجاح لجميع المتدربين..
                                        </p>
                                        <button class="btn btn-primary"><i class="fas fa-angle-double-left"></i>اقرا
                                            المزيد</button>
                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-12 col-lg-5 post container" id="post-4">


                                <div class="row">

                                    <div class="post-img col-lg-5 col-sm-12">
                                        <img src="images/post-3.jpg" alt="news-img">
                                    </div>
                                    <div class="post-content col-lg-7 col-sm-12">

                                        <h5>
                                            هنا سيكون عنوان الخبر
                                        </h5>

                                        <p>
                                            استخدام دالة (VLOOKUP) ومحاضرات مهارات الحاسب للمحاسبين..
                                            نرجو التوفيق والنجاح لجميع المتدربين..
                                        </p>
                                        <button class="btn btn-primary"><i class="fas fa-angle-double-left"></i>اقرا
                                            المزيد</button>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row carousel-item post-continer">
                            <div class="col-sm-12 col-lg-5 post container" id="post-5">

                                <div class="row">

                                    <div class="post-img col-lg-5 col-sm-12">
                                        <img src="images/web-design.jpg" alt="news-img">
                                    </div>
                                    <div class="post-content col-lg-7 col-sm-12">

                                        <h5>
                                            هنا سيكون عنوان الخبر
                                        </h5>

                                        <p>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita mollitia
                                            non
                                            ab tenetur omnis quibusdam natus sunt, officia quae tempore.
                                        </p>
                                        <button class="btn btn-primary"><i class="fas fa-angle-double-left"></i>اقرا
                                            المزيد</button>
                                    </div>

                                </div>
                            </div>
                            <div class="col-sm-12 col-lg-5 post container" id="post-6">

                                <div class="row">

                                    <div class="post-img col-lg-5 col-sm-12">
                                        <img src="images/web-design.jpg" alt="news-img">
                                    </div>
                                    <div class="post-content col-lg-7 col-sm-12">

                                        <h5>
                                            هنا سيكون عنوان الخبر
                                        </h5>

                                        <p>
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita mollitia
                                            non
                                            ab tenetur omnis quibusdam natus sunt, officia quae tempore.
                                        </p>

                                        <button class="btn btn-primary"><i class="fas fa-angle-double-left"></i>اقرا
                                            المزيد</button>

                                    </div>

                                </div>
                            </div>
                        </div>





                    </div>

                </div>
            </div>
        </div>












    </div>




    <div class="container-fluid" id="organization-activities">
        <div class="row title">
            <div class="col-12">
                <h2 id="activities-title">دورات التدريب الحالية</h2>

                <button onClick="scroll_to_top()" id="m" type="button" class="btn btn-warning btn-lg">
                    <i class="fas fa-arrow-alt-circle-up fa-1x"></i>
                </button>
            </div>
        </div>

        <div class="row" id="activities">
            <div class="card col-2" id="first-activity">
                <img class="card-img-top" src="images/accounting.jpg" alt="Card image cap" />
                <div class="card-body">
                    <h5 class="card-title">المحاسبة و المستودعات</h5>
                    <p class="card-text">
                        نعلن عن افتتاح دورة جديدة لبرنامج الأمين للمحاسبة والمستودعات مستوى مبتدئ-متوسط
                    </p>
                    <div class="activities_buttons_div">
                        <a href="#" id="activitie-donation" class="btn btn-primary">تبرع سريع</a>
                        <a href="#" id="activitie-registration" class="btn btn-primary" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasTop" aria-controls="offcanvasTop">طلب تسجيل</a>
                    </div>
                </div>
            </div>
            <div class="card col-2" id="second-activity">
                <img class="card-img-top" src="images/marketing.jpg" alt="Card image cap" />
                <div class="card-body">
                    <h5 class="card-title">التسويق</h5>
                    <p class="card-text">
                        نعلن عن افتتاح دورة جديدة في مجال التسويق مستوى مبتدئ-متوسط

                    </p>
                    <div class="activities_buttons_div">
                        <a href="#" id="activitie-donation" class="btn btn-primary">تبرع سريع</a>
                        <a href="#" id="activitie-registration" class="btn btn-primary" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasTop" aria-controls="offcanvasTop">طلب تسجيل</a>
                    </div>
                </div>
            </div>
            <div class="card col-2" id="third-activity">
                <img class="card-img-top" src="images/desgin.jpg" alt="Card image cap" />
                <div class="card-body">
                    <h5 class="card-title">التصميم الإعلاني</h5>
                    <p class="card-text">
                        نعلن عن افتتاح دورة جديدة في التصميم الإعلاني

                    </p>
                    <div class="activities_buttons_div">
                        <a href="#" id="activitie-donation" class="btn btn-primary">تبرع سريع</a>
                        <a href="#" id="activitie-registration" class="btn btn-primary" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasTop" aria-controls="offcanvasTop">طلب تسجيل</a>
                    </div>
                </div>
            </div>
            <div class="card col-2" id="forth-activity">
                <img class="card-img-top" src="images/web-design.jpg" alt="Card image cap" />
                <div class="card-body">
                    <h5 class="card-title">تصميم مواقع الانترنيت</h5>
                    <p class="card-text">
                        نعلن عن افتتاح دورة جديدة في مجال تصميم مواقع الانترنيت مستوى مبتدئ-متوسط

                    </p>
                    <div class="activities_buttons_div">
                        <a href="#" id="activitie-donation" class="btn btn-primary">تبرع سريع</a>
                        <a href="#" id="activitie-registration" class="btn btn-primary" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasTop" aria-controls="offcanvasTop">طلب تسجيل</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php require "components/footer.php"; ?>




    <div class="offcanvas offcanvas-top" tabindex="-1" id="offcanvasTop" aria-labelledby="offcanvasTopLabel">




        <div class="offcanvas-body">
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>

            <?php require "components/form.php"; ?>
        </div>

    </div>

    <script src="functionality/jquery.js"></script>
    <script src="styles/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="functionality/main.js"></script>
    <script src="functionality/nav-controller.js"></script>

</body>

</html>